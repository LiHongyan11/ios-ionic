angular.module('starter.services',[])

.factory('instance',function(){
  return {}
})
.factory('datas',function(){
  return{}
});
